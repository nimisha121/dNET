pathway1sample.2 <- function(outc, designM, minL2=0,maxL2=0,lambda2=0,id,constr=TRUE, startCis=numeric(), startTrans=matrix(), verbose=FALSE,cvl=F){
	########################################################################################################################
	# fit simultaneous equations model via penalized OLS
	########################################################################################################################
     
	# check input
	#if (verbose){ cat("perform input checks...", "\n") }
	#if (as.character(class(y_j)) != "matrix"){ stop("Input (Y) is of wrong class.") }
	#if (sum(is.na(Y)) != 0){ stop("Matrix Y contains missings.") }
	#if (as.character(class(X)) != "matrix"){ stop("Input (X) is of wrong class.") }
	#if (sum(is.na(X)) != 0){ stop("Matrix X contains missings.") }
	#if (dim(X)[1] != dim(Y)[1]){ stop("Dimension mismatch in columns between matrices X and Y.") }
	#if (dim(X)[2] != dim(Y)[2]){ stop("Dimension mismatch in rows between matrices X and Y.") }
	#if (as.character(class(constr)) != "logical"){ stop("constr of wrong class.") }
	#if (as.character(class(verbose)) != "logical"){ stop("verbose of wrong class.") }
	#if (minL2 == 0 && maxL2 == 0 && lambda2 == 0){ stop("no lambda values given")}

      betaHat= 0 
      transHat = 0
      SigmaHat = 0

	# estimation
		# lasso estimation
                  if(cvl == T){
		      prof <- profL2(outc, penalized = designM[,-1], unpenalized=designM[,1],minlambda2 = minL2,maxlambda2=maxL2,trace=verbose)
                  lambda.2 = prof$lambda[which(prof$cvl==max(prof$cvl))]
		      }else{ 
                      #C = matrix(0,nrow(designM),nrow(designM))
                      #diag(C)= id
                      #DM = C %*% designM[,-1]        
                      penFit <- penalized(outc, penalized = designM[,-1], unpenalized=designM[,1], lambda2=lambda2, trace=verbose)
                      lambda.2 = lambda2
                      # extract lasso estimates
		          transHat <- coef(penFit, "all")[-1]
		          betaHat  <- coef(penFit, "all")[1]
		          SigmaHat <- var(residuals(penFit))
}	
	return(list(Cis=betaHat, Trans=transHat, Sigma=SigmaHat, lambda2=lambda.2)) 
}
