
ntstat <- function(Y,X,gpdata,minl,maxl,nperm){

### X and Y with samples on rows and probes on columns
### gpdata should be a numeric binomial vector
### minl is the minimum lambda limit
### max l is the maximum lambda limit
### nperm how many permutations

#### checks ######
if(length(table(gpdata))!=2){ stop("More than two groups not allowed") }

#gdata = c(1:nrow(Y))
gdata = gpdata
gdata[gpdata==as.numeric(names(table(gpdata))[1])] = (sum(gpdata==as.numeric(names(table(gpdata))[2])))/(length(gdata))
gdata[gpdata==as.numeric(names(table(gpdata))[2])] = -1*((sum(gpdata==as.numeric(names(table(gpdata))[1])))/(length(gdata)))

#### INITIALIZE

n = nrow(Y)
p = ncol(Y)

permmat = nperm

n1 = table(gpdata)[1]
n2 = table(gpdata)[2]

### fit the model per gene
### optimize lambda and get the theta values

lambda_2 = numeric(ncol(Y))
fitbeta = numeric(ncol(Y))
fitsigma = numeric(ncol(Y))
theta = matrix(0,ncol(Y),ncol(Y))
diag(theta) = 1


for (ge in  1:ncol(Y)){

outc = Y[,ge]
designM = cbind(X[,ge],Y[,-ge])

##### fit the model and estimate lambda2
per.sample.cvl <- pathway1sample.2(outc,designM,minL2=minl,maxL2=maxl,cvl=T)
lambda_2[ge] =  per.sample.cvl$lambda2
##### estimate theta and beta

per.sample.fit <- pathway1sample.2(outc,designM,lambda2 = lambda_2[ge],id=gdata)

############################################################################
### Obtain Theta

theta[ge,-ge] = -per.sample.fit$Trans
### get the beta 
fitbeta[ge] = per.sample.fit$Cis

## get sigma

fitsigma[ge] =  per.sample.fit$Sigma
}

Beta = matrix(0,length(fitbeta),length(fitbeta))
diag(Beta) = fitbeta

#### Calculate test statistics

Y1 = Y[gpdata==as.numeric(names(table(gpdata))[2]),] ## resp = 1
Y2 = Y[gpdata==as.numeric(names(table(gpdata))[1]),] ## resp = -1
X1 = X[gpdata==as.numeric(names(table(gpdata))[2]),]
X2 = X[gpdata==as.numeric(names(table(gpdata))[1]),]


## Dim of Y1 :  n1 X p
## Dim of theta : p X p
## Dim of X : n1 X p
## Dim of Beta : p X p 

E_a = t(Y1) %*%((Y1 %*% t(theta)) - (X1 %*% Beta))  ## dim E_a = p X p

##E_a = (2*t(Y1)) %*%((Y1 %*% t(theta)) - (X1 %*% Beta))  ## dim E_a = p X p

## Calculate E_b (error of the model, use estimated theta and Beta)

## Dim of Y2 :  n2 X p
## Dim of theta : p X p
## Dim of X2 : n2 X p
## Dim of Beta : p X p 

E_b = t(Y2) %*%((Y2 %*% t(theta)) - (X2 %*% Beta))  ## dim E_a = p X p

#E_b = (2*t(Y2)) %*%((Y2 %*% t(theta)) - (X2 %*% Beta))  ## dim E_a = p X p

#####################################################################

### Calculate E = E_b - E_a

E = E_b - E_a

Sigma = matrix(0,length(fitsigma),length(fitsigma))
diag(Sigma) = fitsigma

#### Calculate the first differentiation: u

u = (solve(Sigma) %*% t(E))

#u = ((n1 - n2)*solve(theta)) + (1/2)*(solve(Sigma) %*% t(E))

#### Calculate the trace of second differentiation: V

L = (t(Y1) %*% Y1) + (t(Y2) %*% Y2)   ###dim : p X p

tv = -(sum(diag(L) * diag(Sigma)))

### Calculate Omega 

#P = solve(Sigma)  ## dim : p X p
#L = (t(rbind(Y1,Y2))%*%rbind(Y1,Y2)) ## t(Y)%*%Y   dim : p X p
#for(il in  1){Omega.row = P[1,]%*%t(L[,il])
#for (ip in 2:nrow(P)){Omega.row = rbind(Omega.row,P[ip,]%*%t(L[,il]))}
#Omega = Omega.row
#}
 #for(il in  2:ncol(L)){
  #     Omega.row = P[1,]%*%t(L[,il])
   #    for (ip in 2:nrow(P)){
    #       Omega.row = rbind(Omega.row,P[ip,]%*%t(L[,il]))
     #   }
      # Omega = cbind(Omega,Omega.row)
      #}
#V = -((kronecker((-(n1 + n2)*solve(theta)),solve(t(theta)))) - Omega)
#V = (n) * kronecker(solve(theta),solve(t(theta))) - Omega
#V = (1/2)*(V+t(V))


### Test Statistic

## convert matrix u to a vector by stacking all the columns of u under each other.

u = (as.matrix(as.vector(u)))
S = (t(u) %*% u) - tv #solve(V,u) ## Observed Test statistic with V

#### Permutations

#### Permutations

#for(permcol in 1:ncol(permmat)){
#    permmat[,permcol] =  sample(c(1,-1),size=nrow(Y),replace=T)
# }
 for (k in 1:ncol(permmat)){
 	
 	   permY = matrix(0,nrow(Y),nrow(Y))
       diag(permY) = gpdata[permmat[,k]]
       Yperm = t(t(Y) %*% permY)
       
       permX = matrix(0,nrow(Y),nrow(Y))
       diag(permX) = gpdata[permmat[,k]]
       Xperm = t(t(X) %*% permX)


           #### Calculate test statistics
            Betap = Beta
            thetap = theta
            Sigmap = Sigma
            
     
            Y1p = Yperm[gpdata[permmat[,k]]==as.numeric(names(table(gpdata[permmat[,k]]))[2]),]
            Y2p = Yperm[gpdata[permmat[,k]]==as.numeric(names(table(gpdata[permmat[,k]]))[1]),]
            X1p = Xperm[gpdata[permmat[,k]]==as.numeric(names(table(gpdata[permmat[,k]]))[2]),]
            X2p = Xperm[gpdata[permmat[,k]]==as.numeric(names(table(gpdata[permmat[,k]]))[1]),]

            #E_ap = (2*t(Y1p)) %*%((Y1p %*% t(thetap)) - (X1p %*% Betap))  ## dim E_a = p X p
            
            E_ap = t(Y1p) %*%((Y1p %*% t(thetap)) - (X1p %*% Betap))  ## dim E_a = p X p



            ## Calculate E_b (error of the model, use estimated theta and Beta)

            #E_bp = (2*t(Y2p)) %*%((Y2p %*% t(thetap)) - (X2p %*% Betap))  ## dim E_a = p X p

            E_bp = t(Y2p) %*%((Y2p %*% t(thetap)) - (X2p %*% Betap))  ## dim E_a = p X p

            #####################################################################

            ### Calculate E = E_b - E_a

            Ep = E_bp - E_ap


            #### Calculate the first differentiation: u

            #up = ((n1 - n2)*solve(thetap)) + (1/2)*(solve(Sigmap) %*% t(Ep))

            up = (solve(Sigmap) %*% t(Ep))

            #### Calculate the trace of second differentiation: V

            Lp = (t(Y1p) %*% Y1p) + (t(Y2p) %*% Y2p)   ###dim : p X p

            tvp = -(sum(diag(Lp) * diag(Sigmap)))

            #### Calculate the second differentiation: V

            ### Calculate Omega 

            #Pp = solve(Sigmap)  ## dim : p X p
            #Lp = (t(rbind(Y1p,Y2p))%*%rbind(Y1p,Y2p)) ## t(Y)%*%Y   dim : p X p

             #   for(il in  1){
              #    Omega.row = Pp[1,]%*%t(Lp[,il])
               #     for (ip in 2:nrow(Pp)){
                #       Omega.row = rbind(Omega.row,Pp[ip,]%*%t(Lp[,il]))
                 #    }
                 # Omegap = Omega.row
                #}

                #for(il in  2:ncol(Lp)){
                 #Omega.row = Pp[1,]%*%t(Lp[,il])
                  # for (ip in 2:nrow(Pp)){
                   #   Omega.row = rbind(Omega.row,Pp[ip,]%*%t(Lp[,il]))
                   #}
                  #Omegap = cbind(Omegap,Omega.row)
                #}
             #Vp = (n) * kronecker(solve(thetap),solve(t(thetap))) - Omegap
             #Vp = (1/2)*(Vp+t(Vp))

             ### Test Statistic

             ## convert matrix u to a vector by stacking all the columns of u under each other.

             up = (as.matrix(as.vector(up)))

             #S = c(S,(t(up) %*% solve(Vp,up)))  ## Observed Test statistic with V
             S = c(S,(t(up) %*% up) - tvp) #solve(V,u) ## Observed Test statistic with V

         }
   
pval = mean(S[1]<= c(Inf , S[2:(length(S))]))
return(list(npval=pval,permmat=permmat,lambda2 = lambda_2))}
