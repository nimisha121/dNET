################ Figure 4, Figure 5 and Figure 6 in the paper

library(reshape)
library(ggplot2)

### pathways for which the analysis was performed
 
allpath = c("mTOR signaling pathway","TGF-beta signaling pathway","p53 signaling pathway","Apoptosis" , "Wnt signaling pathway", "PI3K-Akt signaling pathway","Notch signaling pathway","ErbB signaling pathway","MAPK signaling pathway")

### TCGA cancer datasets used

can = c("bladder","colon")

#### Initiate

colr = c("red","blue","green","black","orange","grey","magenta","cyan","yellow")
pnts = c(0,1,2,3,4,5,6,8,9)


########## get the p-values and plot Figure 4 in the paper

pathN = matrix(0,length(allpath),length(can))
rownames(pathN) = c("mTOR","TGF-beta","p53","Apoptosis" , "Wnt", "PI3K-Akt","Notch","ErbB","MAPK")
colnames(pathN) = can

setwd(paste(dir,"/bladder/results",sep = ""))
load("network_pval_TCGAbladder.RData")
pathN[,1] = npval

setwd(paste(dir,"/colon/results",sep = ""))
load("network_pval_TCGAcolon.RData")
pathN[,2] = npval

pathN = melt(pathN)
pathN = cbind(rep(1:length(allpath),4),pathN)
colnames(pathN) = c("x","Var1","Var2","value")

bon = 0.05

pl = ggplot(pathN,aes(x=Var1,y=value,color = Var1, shape = Var2))  + xlab("Pathways") + ylab("P-values") + theme(axis.text=element_text(size=20, face = "bold"), axis.title=element_text(size=20,face="bold"),strip.text = element_text(hjust = -0.05)) +theme(legend.title=element_blank()) + geom_point(size=5)+geom_hline(yintercept=bon,linetype = "dotted") + theme(plot.title = element_blank( )) + theme(legend.text=element_text(size=20, face = "bold"))

setwd(paste(dir))

        ggsave(
  "Figure4.png",
  pl,
  width = 23.49,
  height = 10.99,
  dpi = 1200
)

ggsave(plot = pl, file="Figure4.eps",width = 23.49,
  height = 10.99,
  dpi = 1200)


#################################################### Plot Figure 5

rm(list=setdiff(ls(), "dir"))

library(penalized)
library(globaltest)

allpath = "Notch signaling pathway"

can = "colon"

gpf = c(5,4)

thresh = c(0.05,0.09,0.05)

setwd(paste(dir,"/",can,"/data",sep = ""))  

load(paste("cgh","TCGA_",can,"_",allpath,".RData",sep=""))

gp_fac = read.csv(paste(can,"_gp.csv",sep=""))
rownames(gp_fac) = gsub("-",".",gp_fac[,1]) ##### total around 430 samples
gp_fac = gp_fac[colnames(data.cgh),]
gp_fac = gp_fac[,-1]
gp_fac = as.matrix(gp_fac)
### all grp factors

grp_list = as.list(numeric(ncol(gp_fac)))
names(grp_list) = colnames(gp_fac)


##### pathologic stage

clindata = gp_fac[,gpf[2]]
clindata = clindata[(which(clindata != "[Not Available]"))]

clindata[clindata == "Stage I" | clindata == "Stage II"] = -1
clindata[clindata !="-1"] = 1

load(paste("expr","TCGA_",can,"_",allpath,".RData",sep=""))
load(paste("cgh","TCGA_",can,"_",allpath,".RData",sep=""))
load(paste("pexpr","TCGA_",can,"_",allpath,".RData",sep=""))
load(paste("pcgh","TCGA_",can,"_",allpath,".RData",sep=""))

###### Grouping 

class(clindata) = "numeric"
sampleIDs = intersect(names(clindata),colnames(data.cgh))
data.cgh = data.cgh[,sampleIDs]
data.expr = data.expr[,sampleIDs]
clindata = clindata[sampleIDs]
cgh = t(data.cgh)
expr = t(data.expr)

rownames(cgh) <- rownames(expr) <- sampleIDs

colnames(cgh)<-colnames(expr)<-pexpr[,1]
expr = scale(expr,center=T,scale=T)


Y = cgh
 X = expr
 gpdata=clindata
 minl=0.01
 maxl=1000
 
setwd(paste(dir,"/",can,"/scripts",sep = ""))  

source("persampfit_old.R")
source("net_stat_old_withoutV.R")

gdata = gpdata
gdata[gpdata==as.numeric(names(table(gpdata))[1])] = (sum(gpdata==as.numeric(names(table(gpdata))[2])))/(length(gdata))
gdata[gpdata==as.numeric(names(table(gpdata))[2])] = -1*((sum(gpdata==as.numeric(names(table(gpdata))[1])))/(length(gdata)))

#### INITIALIZE

n = nrow(Y)
p = ncol(Y)

n1 = table(gpdata)[1]
n2 = table(gpdata)[2]

### fit the model per gene
### optimize lambda and get the theta values

lambda_2 = numeric(ncol(Y))
fitbeta = numeric(ncol(Y))
fitsigma = numeric(ncol(Y))
theta = matrix(0,ncol(Y),ncol(Y))
diag(theta) = 1

Y1 = Y[gpdata==as.numeric(names(table(gpdata))[2]),] ## resp = 1 ###### status negative
Y2 = Y[gpdata==as.numeric(names(table(gpdata))[1]),] ## resp = -1 ##### status positive
X1 = X[gpdata==as.numeric(names(table(gpdata))[2]),]
X2 = X[gpdata==as.numeric(names(table(gpdata))[1]),]

Y = Y1
X = X1

for (ge in  1:ncol(Y)){

outc = Y[,ge]
designM = cbind(X[,ge],Y[,-ge])

##### fit the model and estimate lambda2
per.sample.cvl <- pathway1sample.2(outc,designM,minL2=minl,maxL2=maxl,cvl=T)
lambda_2[ge] =  per.sample.cvl$lambda2
##### estimate theta and beta

per.sample.fit <- pathway1sample.2(outc,designM,lambda2 = lambda_2[ge],id=gdata)

############################################################################
### Obtain Theta

theta[ge,-ge] = -per.sample.fit$Trans
### get the beta 
fitbeta[ge] = per.sample.fit$Cis

## get sigma

fitsigma[ge] =  per.sample.fit$Sigma
}

Beta = matrix(0,length(fitbeta),length(fitbeta))
diag(Beta) = fitbeta

theta1 = theta
Beta1 = Beta

colnames(theta1) <- rownames(theta1) <- colnames(Y)
colnames(Beta1) <- rownames(Beta1) <- colnames(Y)

#### Calculate test statistics
Y = Y2
X = X2

for (ge in  1:ncol(Y)){

outc = Y[,ge]
designM = cbind(X[,ge],Y[,-ge])

##### fit the model and estimate lambda2
per.sample.cvl <- pathway1sample.2(outc,designM,minL2=minl,maxL2=maxl,cvl=T)
lambda_2[ge] =  per.sample.cvl$lambda2
##### estimate theta and beta

per.sample.fit <- pathway1sample.2(outc,designM,lambda2 = lambda_2[ge],id=gdata)

############################################################################
### Obtain Theta

theta[ge,-ge] = -per.sample.fit$Trans
### get the beta 
fitbeta[ge] = per.sample.fit$Cis

## get sigma

fitsigma[ge] =  per.sample.fit$Sigma
}

Beta = matrix(0,length(fitbeta),length(fitbeta))
diag(Beta) = fitbeta

theta2 = theta
Beta2 = Beta
colnames(theta2) <- rownames(theta2) <- colnames(Y)
colnames(Beta2) <- rownames(Beta2) <- colnames(Y)

colnames(theta1) <- rownames(theta1) <- colnames(theta2) <- rownames(theta2) <- colnames(X1)

setwd(paste(dir))
load("mart.RData")

library(lattice)
library(gplots)


   ### get the chromosome arms 
   results <- getBM(attributes = c("ensembl_gene_id", "hgnc_symbol", "chromosome_name", "strand","band","start_position", "end_position"), filters = "hgnc_symbol", values =  colnames(theta1), mart = mart)
   a1 = which(is.na(as.numeric(results[,3])))
   if(length(a1)>0){results = results[-a1,]}
   chr = results[,3]
   names(chr) = results[,2]
   band = results[,5]
   names(band) = results[,2]
         
   chr = chr[colnames(theta1)]
   band = band[colnames(theta1)]
   colnames(theta1) <- colnames(theta2) <- paste(colnames(theta1)," (",chr,substr(band,start=1,stop=1),")",sep="")

###################################################################################################################

   # Define palette

   #Build the plot
   rgb.palette <- colorRampPalette(c("red","orange","black","cyan","blue"), space = "rgb")
   p1 = levelplot(theta1, aspect = "fill", main= " ", xlab=list("Gene expression", cex=1.5),
      ylab=list("Gene expression", cex=1.5), col.regions=rgb.palette(299), at=seq(-1,1,0.2),colorkey = list(labels=list(cex=1.5))
, scale = list(x = list (cex = 1.5,rot=90),y = list(cex = 1.5)))

   setEPS()
   postscript("Figure5.eps",width = 17.37,height = 12.12)
   print(p1)   
   dev.off()
   
   png(filename="Figure5.png",width = 17.37,height = 12.12,units = "in",res = 1200)
   print(p1)
   dev.off()


   
   #Build the plot
   rgb.palette <- colorRampPalette(c("red","orange","black","cyan","blue"), space = "rgb")
    p1 = levelplot(theta2, aspect = "fill", main= " ", xlab=list("Gene expression", cex=1.5),
      ylab=list("Gene expression", cex=1.5), col.regions=rgb.palette(299), at=seq(-1,1,0.2),colorkey = list(labels=list(cex=1.5))
, scale = list(x = list (cex = 1.5,rot=90),y = list(cex = 1.5)))

  setEPS()
   postscript("Figure6.eps",width = 17.37,height = 12.12)
   print(p1)   
   dev.off()
   
    png(filename="Figure6.png",width = 17.37,height = 12.12,units = "in",res = 1200)
   print(p1)
   dev.off()

   
   
 

