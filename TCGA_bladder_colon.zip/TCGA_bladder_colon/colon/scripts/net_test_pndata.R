rm(list=setdiff(ls(), "dir"))

library(penalized)
library(globaltest)
library(KEGG.db)



allpath = c("mTOR signaling pathway","TGF-beta signaling pathway","p53 signaling pathway","Apoptosis" , "Wnt signaling pathway", "PI3K-Akt signaling pathway","Notch signaling pathway","ErbB signaling pathway","MAPK signaling pathway")

can = c("bladder","colon")

##### select the cancer type and pathway for initializing the matrices

k = 2
path =1

setwd(paste(dir,"/colon/data",sep = ""))

load(paste("cgh","TCGA_",can[k],"_",allpath[path],".RData",sep=""))

##### load clinical information

gp_fac = read.csv(paste(can[k],"_gp.csv",sep=""))
rownames(gp_fac) = gsub("-",".",gp_fac[,1]) ##### total around 430 samples
gp_fac = gp_fac[colnames(data.cgh),]
gp_fac = gp_fac[,-1]
gp_fac = as.matrix(gp_fac)

##### clinical stage

clindata = gp_fac[,4]
clindata = clindata[(which(clindata != "[Not Available]"))]

clindata[clindata == "Stage I" | clindata == "Stage II"|clindata == "Stage IIA" | clindata == "Stage IIB"] = -1
clindata[clindata !="-1"] = 1

#######################################################

npval = numeric(length(allpath))
names(npval) = allpath

########################################################

###### run the analysis for all pathways for colon cancer
	
    if(length(clindata)>1){
        for(path in 1:length(allpath)){
	
load(paste("expr","TCGA_",can[k],"_",allpath[path],".RData",sep=""))
load(paste("cgh","TCGA_",can[k],"_",allpath[path],".RData",sep=""))
load(paste("pexpr","TCGA_",can[k],"_",allpath[path],".RData",sep=""))
load(paste("pcgh","TCGA_",can[k],"_",allpath[path],".RData",sep=""))

###### Grouping 

class(clindata) = "numeric"
sampleIDs = intersect(names(clindata),colnames(data.cgh))
data.cgh = data.cgh[,sampleIDs]
data.expr = data.expr[,sampleIDs]
clindata = clindata[sampleIDs]
cgh = t(data.cgh)
expr = t(data.expr)

print(allpath[path])

rownames(cgh) <- rownames(expr) <- sampleIDs

colnames(cgh)<-colnames(expr)<-pexpr[,1]

expr = scale(expr,center=T,scale=T)

if(path == 1){
permmat = matrix(0,nrow(cgh),1000)
for(pl in 1:ncol(permmat)){
    G1 = which(clindata==as.numeric(names(table(clindata))[1]))
    G2 = which(clindata==as.numeric(names(table(clindata))[2]))
    g1 = sample(c(sample(G1,length(G1)/2),sample(G2,length(G2)/2)))
    g2 = sample(setdiff(c(1:length(clindata)),g1))
    permmat[1:length(g1),pl] = g1
    permmat[(length(g1)+1):nrow(cgh),pl] = g2
}
 save(permmat,file = paste("permmat_gp",".RData",sep=""))
} else {load(paste("permmat_gp",".RData",sep=""))}


### network test ####

setwd(paste(dir,"/colon/scripts",sep = ""))
source("persampfit_old.R")
source("net_stat_old_withoutV.R")
npval[path] = ntstat(Y = cgh, X = expr,gpdata=clindata,minl=0.01,maxl=1000,nperm=permmat)$npval

}
}


setwd(paste(dir,"/colon/results",sep = ""))
save(npval,file = paste("network_pval_","TCGA",can[k],".RData",sep=""))



