rm(list=ls())
library(penalized)
library(globaltest)
library(KEGG.db)
tmp <- tempfile()


#Apoptosis : 23 genes, p53: 15 genes, TGF: 33 genes, mTOR: 14 genes, Wnt: 60 genes
allpath = c("mTOR signaling pathway","TGF-beta signaling pathway","p53 signaling pathway","Apoptosis" , "Wnt signaling pathway")


can = c("breast","colon","bladder")

####Lymphnode metastatis, N status in TNM information ###############

for(k in 1:3){
npval = numeric(length(allpath))
names(npval) = allpath

for(path in 1:length(allpath)){
	
setwd(paste("/svshare/nc/networks_paper_final_scripts/TCGA_datasets/",can[k],sep=""))

load(paste("expr","TCGA_",can[k],"_",allpath[path],".RData",sep=""))
load(paste("cgh","TCGA_",can[k],"_",allpath[path],".RData",sep=""))
load(paste("pexpr","TCGA_",can[k],"_",allpath[path],".RData",sep=""))
load(paste("pcgh","TCGA_",can[k],"_",allpath[path],".RData",sep=""))

load(paste(can[k],"_stagedata.RData",sep=""))

###### Grouping 

clindata = clin.stage[,2]
clindata[clindata=="Stage I" | clindata=="Stage II"] = -1
clindata[clindata=="Stage III" | clindata=="Stage IV"] = 1
clindata = as.numeric(clindata)
names(clindata)=rownames(clin.stage)
data.cgh = data.cgh[,names(clindata)]
data.expr = data.expr[,names(clindata)]
cgh = t(data.cgh)
expr = t(data.expr)

if(path == 1){
permmat = matrix(0,nrow(cgh),1000)
for(pl in 1:ncol(permmat)){
   G1 = which(clindata==as.numeric(names(table(clindata))[1]))
    G2 = which(clindata==as.numeric(names(table(clindata))[2]))
    g1 = sample(c(sample(G1,length(G1)/2),sample(G2,length(G2)/2)))
    g2 = sample(setdiff(c(1:length(clindata)),g1))
    permmat[1:length(g1),pl] = g1
    permmat[(length(g1)+1):nrow(cgh),pl] = g2
}
save(permmat,file = "permmat_stage.RData")
} else {load("permmat_stage.RData")}

### network test ####
setwd("/svshare/nc/networks_paper_final_scripts/TCGA_datasets")
source("persampfit_old.R")
source("net_stat_old_withoutV.R")
npval[path] = ntstat(Y = cgh, X = expr,gpdata=clindata,minl=0.01,maxl=10000,nperm=permmat)$npval

}
setwd(paste("/svshare/nc/networks_paper_final_scripts/TCGA_datasets/",can[k],sep=""))
save(npval,file = paste("network_pval_stage","TCGA",can[k],".RData",sep=""))
}


