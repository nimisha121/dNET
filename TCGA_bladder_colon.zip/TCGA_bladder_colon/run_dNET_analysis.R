####### TCGA cancer data analysis and plots


####### set the working directory to the real_datatheta_sim folder path


dir = "/Users/chaturve/Dropbox/networks_paper_final_scripts/new_results_april2017_sim_TCGA/results/TCGA_bladder_colon_copy"    ###### change this to the preferred directory



######### Bladder cancer data


setwd(paste(dir,"/bladder/scripts",sep = ""))

source("net_test_pndata.R")       #### this script reads in the bladder cancer data for all the pathways and then run the dNET analysis on them


######### Colon cancer data


setwd(paste(dir,"/colon/scripts",sep = ""))

source("net_test_pndata.R")       #### this script reads in the colon cancer data for all the pathways and then run the dNET analysis on them


######### Plot figures 4, 5 and 6

setwd(paste(dir))
source("all_plots_paper.R")       #### this script reads in the colon cancer data for all the pathways and then run the dNET analysis on them



