rm(list=setdiff(ls(), "dir"))


setwd(paste(dir,"real_datatheta_sim/Figure_3/No_assoc/simdata_new",sep = ""))


for(sim in 1:100){


# my.n: length of region (chr arm or genomic region) , equivalent to length(Y), the outcome
# s.size =  sample size, number of arrays corresponding to independent samples
### to run when starting the computations, after the simulations
s.size <- c(200)
my.n = 77

###########################################################################################

simdata <- function (nprobe, nsamp, sigma,abrmean,n){

    ### nprobe: number of probes
    ### nsamp : number of samples
    ### sigma : sd value for rnorm
    ### nsabr : number of samples with abberation
    ### abrstrt: starting probe of the region with abbr
    ### abrend : end probe of the region with abbr
    ### abrmean : mean value for rnorm for similuating the abbr region
    ### abrbeta : value of beta for generating response
    ### lam1 and lam2 : lambda1 and lambda2 values

  a = n
  X <- matrix(0,nprobe,(nsamp/2))

    for (i in 1:(nsamp/2)){
     X[1:nprobe,i] <- rnorm(nprobe,mean=0,sd=sigma)
###### simulated data for all the patients with mean=0
    }

for (i in 1:(nsamp/2)){

#### patients that will have

#### abberations in their copy number profile


if(a[i]==1){ #### diff abrmean for a=1 and a=2
   bl <- 1:4
     b = 1
      X[10:30,i]<-rnorm(length(10:30),mean = abrmean ,sd=sigma)       ###### the values 10:30 and 57:70 decide the region where the CN abberations 
                                                                            ######    will be present. this can be changed.
      X[57:70,i]<-rnorm(length(57:70),mean = abrmean ,sd=sigma)
      }
      ##### copy number abbr in selected region for selected patients




if(a[i]==2){
      X[,i]<-rnorm(nprobe,mean = 0 ,sd=sigma)
      ##### copy number abbr in selected region for selected patients
     }
 }
    ER = numeric(nsamp)
    ER[1:(nsamp/2)] = 1
    ER[((nsamp/2)+1):nsamp]=-1

    colnames(X) = as.character (1:ncol(X))
    rownames(X) = as.character (1:nrow(X))




  return(list(dataX = X,ERinfo = ER))
}

a1 = sample(1:2, 100 ,p=c(0.5,0.5),replace=T)
a2 = sample(1:2, 100 ,p=c(0.5,0.5),replace=T)

sm1 = simdata(nprobe = my.n, n=a1,nsamp = s.size, sigma = 1, abrmean = 3)
#sm2 = simdata(nprobe = my.n, n=a2,nsamp = s.size, sigma = 1, abrmean = 1)


data_same = cbind(sm1$dataX,sm1$dataX)

ER = sm1$ERinfo



nsamp = ncol(data_same)
nprobes = nrow(data_same)






# simul_parameters.R

################################################# gene expression for difference and no diff between the groups ##############################


  ERx = which(ER==1)
  ERz = which(ER==-1)
  xnx = sum(ER==1)
  xnz = sum(ER==-1)
  ymat_no_asso <- matrix(rnorm(nrow(data_same)*ncol(data_same),mean=0,sd=2),nrow=nrow(data_same),ncol=ncol(data_same))



##save data_same, ymat_asso_G1_G2_diff, ER

 save(data_same,file = paste("simCN1_",sim,".RData",sep="")) ## CN
 save(ymat_no_asso,file = paste("simGE1_",sim,".RData",sep="")) ## GE
 save(ER, file = paste("simER1_",sim,".RData",sep="")) ## ER


}