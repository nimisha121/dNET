rm(list=setdiff(ls(), "dir"))

library(penalized)
library(BioPhysConnectoR)

npval = numeric(100)
optlambda = as.list(numeric(100))
proctime = numeric(100)


for(kl in 1:100){
	
setwd(paste(dir,"real_datatheta_sim/Figure_3/No_assoc/simdata_new",sep = ""))

load(paste("simGE1_",kl,".RData",sep=""))

load(paste("simCN1_",kl,".RData",sep=""))

load(paste("simER1_",kl,".RData",sep=""))

Y = ymat_no_asso
gpid = ER
Y = t(Y)

load("permmat.RData")

nperm = permmat

Y1 = Y[gpid == 1,]
Y2 = Y[gpid == -1,]
cov1 = cov(Y1)
cov2 = cov(Y2)

cov1 = scale(cov1,center=T,scale=T)
cov2 = scale(cov2,center=T,scale=T)

fn = fnorm(cov1,cov2)

fnperm = numeric(ncol(nperm))

 for (k in 1:ncol(permmat)){

      gpid1 = gpid[nperm[,k]]
      Y1perm = Y[gpid1 == 1,]
Y2perm = Y[gpid1 == -1,]
cov1perm = cov(Y1perm)
cov2perm = cov(Y2perm)

cov1perm = scale(cov1perm,center=T,scale=T)
cov2perm = scale(cov2perm,center=T,scale=T)

fnperm[k] = fnorm(cov1perm,cov2perm)
}

setwd(paste(dir,"real_datatheta_sim/Figure_3/No_assoc/results",sep = ""))
npval[kl] = mean(fn <= c(Inf , fnperm[1:(length(fnperm))]))
save(npval,file ="npval_fnorm.RData")
}
       

