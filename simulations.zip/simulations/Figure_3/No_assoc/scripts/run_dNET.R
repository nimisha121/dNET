rm(list=setdiff(ls(), "dir"))

library(penalized)


#n1 = 10
#n2 = 10
#n = n1+n2

npval = numeric(100)
optlambda = as.list(numeric(100))
proctime = numeric(100)


for(kl in 1:100){
	
setwd(paste(dir,"real_datatheta_sim/Figure_3/No_assoc/simdata_new",sep = ""))

load(paste("simGE1_",kl,".RData",sep=""))

load(paste("simCN1_",kl,".RData",sep=""))

load(paste("simER1_",kl,".RData",sep=""))

Y = ymat_no_asso
gpid = ER
Y = t(Y)

X = data_same
X = t(X)

if(kl == 1){
permmat = matrix(0,nrow(Y),1000)
for(pl in 1:ncol(permmat)){
   G1 = which(gpid==as.numeric(names(table(gpid))[1]))
    G2 = which(gpid==as.numeric(names(table(gpid))[2]))
    g1 = sample(c(sample(G1,length(G1)/2),sample(G2,length(G2)/2)))
    g2 = sample(setdiff(c(1:length(gpid)),g1))
    permmat[1:length(g1),pl] = g1
    permmat[(length(g1)+1):nrow(Y),pl] = g2
}
save(permmat,file = "permmat.RData")
} else {load("permmat.RData")}

nperm = permmat


setwd(paste(dir,"real_datatheta_sim/Figure_3/No_assoc/scripts",sep = ""))

source("net_stat_old_withoutV.R")
source("persampfit_old.R")

time1 = proc.time()[3]
overallstat = ntstat(Y = Y, X = X,gpdata=gpid,minl=0.01,maxl=10000,nperm = permmat)
time2 = proc.time()[3]

proctime[kl] = time2 - time1

npval[kl] = overallstat$npval
optlambda[[kl]] = overallstat$lambda2

setwd(paste(dir,"real_datatheta_sim/Figure_3/No_assoc/results",sep = ""))

save(npval,file ="npval.RData")
save(optlambda,file ="optlambda.RData")
save(proctime,file ="proctime.RData")
}


