####### Simulation analysis results and plots

####### set the working directory to the real_datatheta_sim folder path


dir = "/Users/chaturve/Dropbox/networks_paper_final_scripts/new_results_april2017_sim_TCGA/results/simulations"    ###### change this to the preferred directory



######### For Simulation study 1, scenario 1 (without differential networks), Figure 1 (blue triangles)
####### Folder : simulations -> Figure1_and_Figure2A -> no_effect




setwd(paste(dir,"/Figure1_and_Figure2A/no_effect/Theta_from_data",sep = ""))

source("Simulate_data.Rd")       #### this script simulates the data and saves it in the simdata folder
source("run_simulation_final.R")    ##### this script runs the analysis and saves the results in the results folder




######### For Simulation study 1, scenario 2 (with differential networks),  Figure 1 (red dots)
######### For simulation study 2, scenario 2 (with differential networks),  Figure 2A
####### Folder : simulations -> Figure1_and_Figure2A -> with_effects


setwd(paste(dir,"/Figure1_and_Figure2A/with_effects/Theta_from_data",sep = ""))

source("Simulate_data.Rd")    
source("run_simulation_final.R")    



######### For simulation study 2, scenario 2 (with differential networks),  Figure 2B
####### Folder : simulations -> Figure_2B -> with_effects

setwd(paste(dir,"/Figure_2B/with_effects/Theta_from_data",sep = ""))

source("Simulate_data.Rd")    
source("run_simulation_final.R")   



######### Figure 3 in the paper


########## With assoc between CN nad GE

setwd(paste(dir,"real_datatheta_sim/Figure_3/Assoc/scripts",sep = ""))

source("Simulate_data_networks_revision.R")    

#### run the approac based on frobenius norm

source("run_frobenius.R")   

#### run dNET

source("run_dNET.R")    

###############################################################################################################


########## With no assoc between CN nad GE

setwd(paste(dir,"real_datatheta_sim/Figure_3/No_assoc/scripts",sep = ""))

source("Simulate_data_networks_revision.R")    

#### run the approac based on frobenius norm

source("run_frobenius.R")   

#### run dNET

source("run_dNET.R")   


###############################################################################################################


########## With same assoc between CN nad GE

setwd(paste(dir,"real_datatheta_sim/Figure_3/Same_assoc/scripts",sep = ""))

source("Simulate_data_networks_revision.R")    

#### run the approac based on frobenius norm

source("run_frobenius.R")   

#### run dNET

source("run_dNET.R")



##############################################################################################################

######## Plot the figures
##### All the plots (Figure1,2 and 3) will be saved in dir

setwd(paste(dir))

source("final_paper_plots_simulation.R")    