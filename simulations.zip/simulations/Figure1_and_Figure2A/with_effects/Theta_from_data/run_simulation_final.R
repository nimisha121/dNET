
### Run the simulation analysis for simulation 1 and 2 (Figure 1 and Figure 2A) with differential networks 

rm(list=setdiff(ls(), "dir"))

library(penalized)


#n1 = 10
#n2 = 10
#n = n1+n2

numsamp = c(50,100,150,200,250,300,350,400,450,500)
for(i in 1:10){
	
	npval = numeric(100)
optlambda = as.list(numeric(100))
proctime = numeric(100)


for(kl in 1:100){
	
setwd(paste(dir,"/Figure1_and_Figure2A/with_effects/Theta_from_data/simdata",sep = ""))

load(paste("X_",kl,"_numsamp_",i,".RData",sep = ""))
load(paste("Y_",kl,"_numsamp_",i,".RData",sep = ""))
load(paste("gpid_",kl,"_numsamp_",i,".RData",sep = ""))

gpdata=gpid
minl=0.01
maxl=10000

if(kl == 1){
permmat = matrix(0,nrow(Y),1000)
for(pl in 1:ncol(permmat)){
   G1 = which(gpid==as.numeric(names(table(gpid))[1]))
    G2 = which(gpid==as.numeric(names(table(gpid))[2]))
    g1 = sample(c(sample(G1,length(G1)/2),sample(G2,length(G2)/2)))
    g2 = sample(setdiff(c(1:length(gpid)),g1))
    permmat[1:length(g1),pl] = g1
    permmat[(length(g1)+1):nrow(Y),pl] = g2
}
save(permmat,file = paste("permmat_",i,"_sampsize",".RData",sep = ""))
} else {load(paste("permmat_",i,"_sampsize",".RData",sep = ""))}


nperm=permmat

setwd(paste(dir,"/Figure1_and_Figure2A/with_effects/Theta_from_data",sep = ""))

source("net_stat_old_withoutV.R")
source("persampfit_old.R")

time1 = proc.time()[3]
overallstat = ntstat(Y = Y, X = X,gpdata=gpid,minl=0.01,maxl=10000,nperm = permmat)
time2 = proc.time()[3]

proctime[kl] = time2 - time1

npval[kl] = overallstat$npval
optlambda[[kl]] = overallstat$lambda2


setwd(paste(dir,"/Figure1_and_Figure2A/with_effects/Theta_from_data/results",sep = ""))

save(npval,file = paste("npval_","numsamp_",i,".RData",sep = ""))
save(optlambda,file = paste("optlambda_","numsamp_",i,".RData",sep = ""))
save(proctime,file =paste("proctime_","numsamp_",i,".RData",sep = ""))
     }
 }




