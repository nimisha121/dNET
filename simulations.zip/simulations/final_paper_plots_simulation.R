rm(list=setdiff(ls(), "dir"))


multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)

  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)

  numPlots = length(plots)

  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                    ncol = cols, nrow = ceiling(numPlots/cols))
  }

 if (numPlots==1) {
    print(plots[[1]])

  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))

    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))

      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}



########### Figure 1 in the paper

library(ggplot2)
library(reshape2)

setwd(paste(dir,"/Figure1_and_Figure2A/with_effects/Theta_from_data/results",sep = ""))

pval = matrix(0,100,2)

i = 4   ##### simulation run with 200 samples

	load(paste("npval_numsamp_",i,".RData",sep = ""))
	pval[,1] = npval
	
setwd(paste(dir,"/Figure1_and_Figure2A/no_effect/Theta_from_data/results",sep = ""))

i = 4 ##### simulation run with 200 samples

	load(paste("npval_numsamp_",i,".RData",sep = ""))
	pval[,2] = npval

colnames(pval) = as.character(c("Differential network nodes between G1 and G2","Similar network nodes between G1 and G2"))

Pval = melt(pval)
colnames(Pval) = c("X1","X2","value")

pl = ggplot(Pval,aes(x=X1,y=value ,shape=X2, color = X2)) + xlab("Simulations") + ylab("P-values") +theme(legend.title=element_blank()) + geom_point(size = 3)+ geom_hline(yintercept=0.01,linetype = "dashed") + theme(plot.title = element_blank(), axis.text=element_text(size=20, face = "bold"),
        axis.title=element_text(size=20,face="bold")) + theme(legend.text=element_text(size=20, face = "bold"))
        
        setwd(paste(dir))

        ggsave(
  "Figure1.png",
  pl,
  width = 23.49,
  height = 10.99,
  dpi = 1200
)

ggsave(plot = pl, file="Figure1.eps",width = 23.49,
  height = 10.99,
  dpi = 1200)


###################### Figure 2A in the paper

library(ggplot2)
library(reshape2)

setwd(paste(dir,"/Figure1_and_Figure2A/with_effects/Theta_from_data/results",sep = ""))

pval = matrix(0,100,10)

for(i in 1:10){
	load(paste("npval_numsamp_",i,".RData",sep = ""))
	pval[,i] = npval
}

colnames(pval) = as.character(c(50,100,150,200,250,300,350,400,450,500))

Pval = melt(pval)
colnames(Pval)[2:3] = c("GP","Pvalues")
Pval$GP = as.factor(Pval$GP)

p1 = ggplot(Pval, aes(x= GP, y=Pvalues)) + geom_boxplot(notch=TRUE) +xlab("Sample size") + ylab("P-values") + ggtitle("A") + theme(plot.title = element_text(hjust = 0.5, size = 20, face = "bold"), axis.text=element_text(size=20, face = "bold"),
        axis.title=element_text(size=20,face="bold")
) + theme(legend.title = element_text(size=20,face="bold"), legend.text=element_text(size=20, face = "bold")
)


###################### Figure 2B in the paper

setwd(paste(dir,"/Figure_2B/with_effects/Theta_from_data/results",sep = ""))


pval = matrix(0,100,10)

for(i in 1:10){
	load(paste("npval_gpsize",i,".RData",sep = ""))
	pval[,i] = npval
}

colnames(pval) = c("10 - 190", "20 - 180","30 - 170","40 - 160","50 - 150","60 - 140","70 - 130","80 - 120", "90 - 110","100 - 100")

Pval = melt(pval)
colnames(Pval)[2:3] = c("GP","Pvalues")

Pval$GP <- factor(Pval$GP,
    levels = c("10 - 190", "20 - 180","30 - 170","40 - 160","50 - 150","60 - 140","70 - 130","80 - 120", "90 - 110","100 - 100"),ordered = TRUE)


p2 = ggplot(Pval, aes(x= GP, y=Pvalues)) + geom_boxplot(notch=TRUE) +xlab("Group size (G1-G2)") + ylab("P-values") + ggtitle("B") +  theme(plot.title = element_text(hjust = 0.5, size = 20, face = "bold"), axis.text=element_text(size=20, face = "bold"),
        axis.title=element_text(size=20,face="bold")
) + theme(legend.title = element_text(size=20,face="bold"), legend.text=element_text(size=20, face = "bold")
)

        setwd(paste(dir))


    ggsave(
  "Figure2.png",
  multiplot(p1,p2,cols=1),
  width = 23.49,
  height = 10.99,
  dpi = 1200
)

ggsave(plot = multiplot(p1,p2,cols=1), file="Figure2.eps",width = 23.49,
  height = 10.99,
  dpi = 1200)



############################################

###################### Figure 3A in the paper


library(ggplot2)
library(reshape2)


pval = matrix(0,100,3)

setwd(paste(dir,"/Figure_3/Assoc/results",sep = ""))

load("npval.RData")
pval[,1] = npval

setwd(paste(dir,"/Figure_3/No_assoc/results",sep = ""))
load("npval.RData")
pval[,2] = npval

setwd(paste(dir,"/Figure_3/Same_assoc/results",sep = ""))
load("npval.RData")
pval[,3] = npval

pval = cbind(c(1:100),pval)
colnames(pval) = as.character(c("Samp","Asso","No_asso","Same_asso"))

### TN and FP

TN1 = sum(pval[,2]>0.01)   ##### Asso
FP1 = sum(pval[,2]<0.01)
SP1 = (TN1/100)*100

TN2 = sum(pval[,3]>0.01)   ###### No_assoc
FP2 = sum(pval[,3]<0.01)
SP2 = (TN2/100)*100

TN3 = sum(pval[,4]>0.01)   ##### Same_assoc
FP3 = sum(pval[,4]<0.01)
SP3 = (TN3/100)*100

sp = c(TN1,TN2,TN3,FP1,FP2,FP3)
Asso = c(rep(c("Differential association between X and Y","No association between X and Y","Similar association between X and Y for two groups"),2))
x = rep(c(1:3),2)
y = c(rep("True Negative",3),rep("False Positives",3))
SP = as.data.frame(cbind(x,y,sp,Asso))

colnames(SP) = c("x","cl","sp","Cases")

p1 = ggplot(SP,aes(x=x,y=sp,color = cl ,shape=Cases)) + scale_y_discrete(breaks = c(seq(from = 0, to = 100,by=10)), labels = as.character(seq(from = 0, to = 100,by=10)), limits = as.character(seq(from = 0, to = 100,by=1))) + xlab("Cases") + ylab("Total True negatives/False positives\nfor 100 simulations") +  ggtitle("A") +  theme(plot.title = element_text(hjust = 0.5, size = 20, face = "bold"), axis.text=element_text(size=20, face = "bold"), axis.title=element_text(size=20,face="bold")) + theme(legend.title=element_blank()) + geom_point(size=5) + theme(legend.text=element_text(size=20, face = "bold"))


########## Figure 3B in the paper

library(ggplot2)
library(reshape2)

setwd(paste(dir,"/Figure_3/Assoc/results",sep = ""))
load("npval_fnorm.RData")
fpval = npval

setwd(paste(dir,"/Figure_3/No_assoc/results",sep = ""))
load("npval_fnorm.RData")
fpval = cbind(npval,fpval)

setwd(paste(dir,"/Figure_3/Assoc/results",sep = ""))
load("npval.RData")
dpval = npval

setwd(paste(dir,"/Figure_3/No_assoc/results",sep = ""))
load("npval.RData")

dpval = cbind(npval,dpval)
ID = c(rep("Frobenius norm",100),rep("dNET",100))
pval1 = c(fpval[,1],dpval[,1])
pval2 = c(fpval[,2],dpval[,2])
df1 = data.frame(ID,pval1,pval2)
colnames(df1) = c("Association_tests","No association between X and Y","Differential association between X and Y")
df2 = melt(df1)

p2 <-ggplot(df2, aes(x = Association_tests, y = value, fill = variable)) +
        geom_boxplot(alpha=1) +
        scale_y_continuous(name = "Association p-values",
                           breaks = seq(0, 1, 0.1),
                           limits=c(0, 1)) +
        scale_x_discrete(name = "Association tests") +
        theme_bw() + ggtitle("B") + 
        theme(plot.title = element_text(hjust = 0.5, size = 20, face = "bold"), axis.text=element_text(size=20, face = "bold"), axis.title=element_text(size=20,face="bold")) + 
        theme(legend.position = "bottom") +
        scale_fill_brewer(palette = "Accent") +
        labs(fill = " ") + theme(legend.text=element_text(size=20, face = "bold")) + guides(colour = guide_legend(override.aes = list(size=20)))
        
        

      setwd(paste(dir))


    ggsave(
  "Figure3.png",
  multiplot(p1,p2,cols=1),
  width = 23.49,
  height = 10.99,
  dpi = 1200
)

ggsave(plot = multiplot(p1,p2,cols=1), file="Figure3.eps",width = 23.49,
  height = 10.99,
  dpi = 1200)

